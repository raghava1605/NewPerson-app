import React,{Component} from 'react';
// import PersonNew from './PersonNew';
class PeopleNew extends Component{
    

render(){
console.log(this.props.PersonNewNames)
    return(<div>
        {this.props.PersonNewNames.length>0 && this.props.PersonNewNames.map((item, index) => (
        <div key={index} className = "personnewnames">      
        <button onClick={()=>{this.props.delete(item)}}> x </button>
            <div>{item.name} {item.Age}</div>
            </div> 
            ))}
          
        </div>
    )
}

}
export default PeopleNew;