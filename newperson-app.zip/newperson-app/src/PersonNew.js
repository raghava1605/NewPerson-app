import React,{Component} from 'react';

class PersonNew extends Component{

    render(){
        return(
            <p>Person</p>
        )
    }
}

export default PersonNew;