import React,{Component} from 'react';

class AddPersonNew extends Component{

   constructor(){
       super();
       this.state= {name: "", Age: ""}
   }

updateName = (val) =>{
this.setState({name:val})
}

updateAge = (val) =>{
    this.setState({Age:val})

}

    render(){
        return(
        <div className= "addpersonnew">
            <div >
                <input type="text" name= "name" onChange= {e => this.updateName(e.target.value)}/>
                </div>
                <div>
                <input type="text" name="Age" onChange= {e => this.updateAge(e.target.value)}/> </div>
                <div>
                <button onClick = {() => this.props.addIemsNew(this.state.name, this.state.Age)} type="button">Add </button>
                </div> 
                </div>
        )
    }
}

export default AddPersonNew;

