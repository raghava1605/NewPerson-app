import React from 'react';
import PeopleNew from './PeopleNew';
import AddPersonNew from './AddPersonNew';
import './App.css';


class App extends React.Component{

  constructor(props){
    super(props);
    this.state={
    PersonNewNames:[{id: 0,name:"Sona", Age:"12"},{id: 1,name:"Mona", Age:"14"},{id: 2,name:"Shona", Age:"16"}]
    }
}

addIemsNew = (name,Age) =>{
  // const newPersonNames= this.state.PersonNewNames;
  // newPersonNames.push({name, Age})
  var newPerson = {name:name, Age: Age}
this.setState({PersonNewNames:[...this.state.PersonNewNames, {...newPerson,id:this.state.PersonNewNames.length  }]})
}

delete= (item) =>{

  this.setState({PersonNewNames: this.state.PersonNewNames.slice(0, item.id).concat(this.state.PersonNewNames.slice(item.id+1))});

  
 
}
  render(){
    return(
      <div>
        <AddPersonNew addIemsNew={this.addIemsNew}/>
        <PeopleNew PersonNewNames={this.state.PersonNewNames} delete={this.delete}/>
        </div>
    )
  }
}


export default App;
