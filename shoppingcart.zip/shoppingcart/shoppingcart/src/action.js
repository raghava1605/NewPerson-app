export const SUMMARY = 'SUMMARY';

const update_summary = payload => ({type:SUMMARY, payload });

export const actions= {update_summary};