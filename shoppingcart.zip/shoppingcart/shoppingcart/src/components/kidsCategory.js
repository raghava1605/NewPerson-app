import React,{Component,Fragment} from 'react';

class KidsCategory extends Component{

    render(){
        return(
            <Fragment>
                <h2> Yo kiddoo...! </h2>
                </Fragment>
        )
    }
}


export default KidsCategory;