import React,{Component,Fragment} from 'react';

class WomenCategory extends Component{

    render(){
        return(
            <Fragment>
              <h2>  Hi Lady! </h2>
                </Fragment>
        )
    }
}

export default WomenCategory;